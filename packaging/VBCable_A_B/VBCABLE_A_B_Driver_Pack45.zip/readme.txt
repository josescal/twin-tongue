-----------------------------------------------------------------
VB-CABLE A+B (Audio Device Driver MME, DX, WDM)
-----------------------------------------------------------------

CONTENT:
   - INSTALLATION 	    
   - LICENSE 	    
   - CONTACT.


-----------------------------------------------------------------
VB-CABLE A+B (Audio Device driver)
-----------------------------------------------------------------

Programmed by V.Burel / JS-Loezic

Copyrights V.Burel�2010-2025 All rights reserved.

VB-CABLE is an Audio Driver working as virtual audio cable.
All signals sent to the device output is going on the device input.

Licensing: https://vb-audio.com/Services/licensing.htm

Since 2024, VB-CABLE for Windows 10 x64 is offering up to 16 channels
and ARM64 support.


-----------------------------------------------------------------
INSTALLATION (for new package - pack45).
-----------------------------------------------------------------

Just run the VBCable_AB_PackSetup.exe program to install latest version.
it will copy file in C:\Program Files (x86)\VB\VBCABLE_AB_Pack
and automatically install driver from this folder.

VBCABLE_A_ControlPanel and VBCABLE_B_ControlPanel (version 3.3.1.9) 
will be available in 
- C:\Program Files (x86)\VB\VBCABLE_AB_Pack or
- C:\Program Files\VB\CABLE-A
- C:\Program Files\VB\CABLE-B

To finalize installation, you must reboot your computer.
To finalize uninstallation, you must also reboot your computer.



----------------------------------------------------------------
INSTALLATION (for old package - pack43).
-----------------------------------------------------------------

if you want to install old version, you must unzip the following
zip package into a temporary folder and run setup program for each package:
VBCABLE_A_Driver_Pack43.zip
VBCABLE_B_Driver_Pack43.zip


Just UNZIP the package in a folder somewhere on your hard-disk and 
launch the Setup program from there (! IN ADMINISTRATOR MODE !).

- VBCABLE_Setup.exe will install driver on 32 bit O/S
(will do nothing on 64 bit O/S)

- VBCABLE_Setup_x64.exe will install driver on 64 bit O/S
(will not run on 32bits O/S)

During installation, the Setup Application can be shown as 
"not responding" for few seconds. It is not a problem, 
just wait the end of the installation (a dialog-box will say you
when it is finished). 

To finalize installation, you must reboot your computer.
To finalize uninstallation, you must also reboot your computer.




-----------------------------------------------------------------
LICENSE
-----------------------------------------------------------------

LICENCE AGREEMENT

Vincent Burel (the author) give you (an individual
or a single entity) permission to use this software.
All files are protected by copyright and are 
property of Vincent Burel (The Author) according to
intellectual property laws and treaties. 
Softwares, files and documents are not public 
domain, and are protected by the copyright laws
of France. So you may not sublicense, rent, lease, 
convey, distribute, copy, modify, translate, convert
to another programming language, decompile, 
disassemble the Software for any purpose. 


DISCLAIMER: 

THE SOFTWARE AND DOCUMENTATIONS, TECHNICAL
OR NOT ARE PROVIDED AS-IS, WITHOUT WARRANTY
OF ANY KIND. VINCENT BUREL (THE AUTHOR)
DISCLAIMS ALL WARRANTIES RELATING TO THE
SOFTWARE, WHETHER EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO ANY IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE, AND ALL SUCH 
WARRANTIES ARE EXPRESSLY AND SPECIFICALLY
DISCLAIMED.

THE AUTHOR SHALL NOT BE LIABLE FOR ANY 
INDIRECT, CONSEQUENTIAL OR INCIDENTAL
DAMAGES ARISING OUT OF THE USE OR INABILITY
TO USE THE SOFTWARE EVEN IF THE AUTHOR HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES OR CLAIMS. THE USER OF THE SOFTWARE
BEARS ALL RISK AS TO THE QUALITY AND
PERFORMANCE OF THE SOFTWARE.
DISCLAIMER: 


-----------------------------------------------------------------
CONTACT
-----------------------------------------------------------------

contact : https://vb-audio.com/Services/contact.htm

WEB : http://www.vb-audio.com
WEB : http://www.vb-cable.com